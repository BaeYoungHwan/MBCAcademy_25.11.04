
public class MainClass {
	public static void main(String[] args) {
		/*
			bit 연산
			low level
			(처리)속도가 빠르다
			
			bit : 0, 1
		
			&	AND
			|	OR
			^	XOR
			<<	left shift
			>>	right shift  
			~	NOT
			
			1100 1010
			8421 8421
			C	 A 	
			
			1111 0000
			F	 0
		*/
		
		// AND
		/*
				0 0 -> 0
				0 1 -> 0
				1 0 -> 0
				1 1 -> 1
				
				1100 1010	-> CA
				1111 0000	-> F0
				1100 0000
				C    0 				
		*/
		int result = 0xCA & 0xF0;
		System.out.println(result);
		System.out.printf("0x%x \n", result);
		
		/*
		char c = 'A';
		System.out.printf("%c", c);	// 문자
		System.out.printf("%d", (int)c);	// 숫자
		*/
		
		// OR
		/*
				0 0 -> 0
				0 1 -> 1
				1 0 -> 1
				1 1 -> 1
				
				1100 1010	-> CA
				1111 0000	-> F0
				1111 1010
				F	 A		
		*/
		result = 0xCA | 0xF0;
		System.out.printf("0x%x\n", result);
		
		// XOR
		/*
				0 0 -> 0
				0 1 -> 1
				1 0 -> 1
				1 1 -> 0
				
				1100 1010	-> CA
				1111 0000	-> F0
				0011 1010
				3    A 
				
				보안
				암호화 ---> 복호화
				aaa er2   aaa
								
				1110 1001	원본		1110 1001 1010 1100
				1010 1100   key
				0100 0101	암호화된 코드
				1010 1100   key
				1110 1001	복호화된 코드				
		*/
		result = 0xCA ^ 0xF0;
		System.out.printf("0x%x \n", result);
		
		
		// left shift
		/*
		 	number = number * 2
		 	
		 	0000 0001	-> 1
		 	0000 0010	-> 2
		 	0000 0100	-> 4
		 	0000 1000
		  		 8421	
		  	
		  	8421 8421
		  	0011 1000 -> 0111 0000	 
		  	3 	 8		 7    0
		 */
		byte by;
		by = 0x38 << 1;
		System.out.printf("0x%x \n", by);
		
		// ~
		/*
		  	0 -> 1
		  	1 -> 0
		  	
		  	0010 1010
		  	8421 8421
		  	
		    1101 0101 
		    8421 8421
		  	D 	 5		  
		*/
		byte by1 = ~0x2a;
		System.out.printf("0x%x \n", by1);
		
		
		
	}
}




