
public class MainClass {
	public static void main(String[] args) {
		/*
			Wrapper class
			: 일반 자료형(char, int, double)들을 class 화 시켜놓은 것
			int + 기능
			변수처럼 사용도 가능하다
			
			일반자료형				Wrapper class
			boolean				Boolean
			short				Short
			int					Integer		--->
			long				Long
			
			float				Float
			double				Double		--->
			
			char				Character
			char의 묶음			String		--->
			
			Object Oriented Programming
			객체	   지향      
		*/
		int number = 123;
		Integer iNumber = 234;
		System.out.println("number = " + number);
		System.out.println("iNumber = " + iNumber);
		
		// + 기능
		// 변수(iNumber).함수(기능)
		
		// 숫자 -> 문자열		123 -> "123"
		System.out.println(123 + 111);
		System.out.println("123" + 111);
				
		String str = "123";
		
		str = iNumber.toString();
		System.out.println(str);
		
		str = iNumber + "";
		str = number + "";
		
		// 문자열 -> 숫자
		// "1024" -> 1024
		String strNumber = "1024";
		number = Integer.parseInt(strNumber);
		System.out.println(number + 1);
		
		strNumber = "123.4567";
		double dnumber = Double.parseDouble(strNumber);
		System.out.println(dnumber + 1);
		
		// 10진수 -> 2진수(문자열)
		int n10 = 33;
		String n2 = Integer.toBinaryString(n10);
		System.out.println(n10 + " -> " + n2);
		
		n2 = "11001010";
		// 2진수 -> 10진수
		n10 = Integer.parseInt(n2, 2);
		System.out.println(n2 + " -> " + n10);
		
		// 10진수 -> 16진수(String)
		n10 = 162;
		String n16 = Integer.toHexString(n10);
		System.out.println(n10 + " -> " + n16);
		
		// 16진수 -> 10진수
		n16 = "CA";
		n10 = Integer.parseInt(n16, 16);
		System.out.println(n16 + " -> " + n10); 
		
		int num16 = 0x134;
		
		
	}
}








