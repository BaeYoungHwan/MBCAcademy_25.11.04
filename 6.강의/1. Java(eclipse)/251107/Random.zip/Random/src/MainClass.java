
public class MainClass {
	public static void main(String[] args) {
		/*
			random : 난수, 무작위	
			
			1 2 3 4 5 -> 3			
		*/
		
		int r;
		
		// 0 ~ 4
		r = (int)(Math.random() * 5);
		System.out.println("r = " + r);
		
		// 1 ~ 10
		r = (int)(Math.random() * 10) + 1;
		System.out.println("r = " + r);
		
		// -1 0 1
		int x = (int)(Math.random() * 3) - 1;	// -1 0 1
		int y = (int)(Math.random() * 3) - 1;	// -1 0 1
		System.out.println("r = " + r);
		
		
	}
}



