import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class MainClass {
	public static void main(String[] args)  {
		
		// 파일 쓰기(write) : 파일이 없으면 (자동)생성 + 쓰기가 된다
		//                : 파일이 있으면 덮어쓰기(기존의 내용 삭제)	
		File file = new File("c:\\tmp\\test.txt");
		
		// 한문자씩 쓰기
		/*
		try {
//			FileWriter fw = new FileWriter(file);
//			fw.write("반갑습니다" + "\n");
//			fw.close();
			
			// 추가쓰기
			FileWriter fw = new FileWriter(file, true);
			fw.write("건강하세요" + "\n");
			fw.close();
			
		} catch (IOException e) {			
			e.printStackTrace();
		}
		*/
		
		// 문장으로 쓰기
		try {
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);
			
			pw.print("안녕" + "\n");
			pw.println("하이");
			pw.println("환영");
			
			pw.close();
			
		} catch (IOException e) {			
			e.printStackTrace();
		}
		
		
	}
}





