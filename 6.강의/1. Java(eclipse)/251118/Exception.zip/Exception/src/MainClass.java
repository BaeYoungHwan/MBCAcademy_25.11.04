
public class MainClass {
	public static void main(String[] args) {
		/*
			Exception : 예외(처리) != error
						예상외
			계산기 -> 숫자입력	0 ~ 9
						    A -> 65 
			Number -> format        -> 예외
			
			Array -> int array[] = new int[5];
					 array[0 ~ 4]
					 array[5] = 23;	-> 예외
					 
			class -> Scanner 못찾는 경우  -> 예외
					 
			file  -> read, write   
					 file 이 없는 경우    -> 예외
					 
			try{
					 
				예외1가 나올 가능성이 있는 소스코드
				예) 숫자 배열 입력
				
				예외2가 나올 가능성이 있는 소스코드
				예) 배열 index 접근 
				
							:
			
			}catch(예외 클래스1 e){
				예외가 나온 경우의 처리
			}catch(예외 클래스2 e){
				예외가 나온 경우의 처리
			}finally{	// 생략이 가능
				무조건 실행!
				반드시 해야 될 뒷처리
				
				예) file.close database.close
			}
			
			함수에 적용
			void function() throws 예외클래스 {
			
			}	
		*/
		
		int array[] = { 1, 2, 3 };
		
		System.out.println("프로그램 시작");
		
		try {
			for (int i = 0; i < 4; i++) {
				System.out.println(array[i]);
			}	
		}catch (ArrayIndexOutOfBoundsException e) {
			//System.out.println("배열의 범위 초과");
			//e.printStackTrace();
			System.out.println(e.getMessage());
		} finally {
			System.out.println("반드시 실행됨");
		}
		
		System.out.println("프로그램 종료");
	}
}














