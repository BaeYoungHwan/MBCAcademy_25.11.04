import java.util.Arrays;

public class MainClass {
	public static void main(String[] args) {
		
		// 1.배열의 값에 *2배의 연산된 값이 산출되도록 메소드를 작성하시오.
		/*
		int num1[] = {1, 2, 3, 4, 5};
		//num1 = getDouble(num1);
		getDouble(num1);
		System.out.println(Arrays.toString(num1));
		*/
		
		//int num = 0, array[] = { 1, 2, 3 };
		//function(num, array);		
		
		// 2.두 수를 나눗셈 연산으로 몫과 나머지를 구하는 메소드를 작성하시오
		/*
		int num1, num2;
		int result;				// 몫 
		int tag[] = new int[1];	// 나머지
		
		num1 = 9;
		num2 = 2;
		
		result = getResult(num1, num2, tag);
		System.out.println("몫:" + result + " 나머지:" + tag[0]);
		*/
		
		// 3.두 점 (x, y)와 (x1, y1)간의 거리를 구한다
		/*
		double d = getDistance(1, 1, 2, 2);
		System.out.println(d);
		*/
		
		// 4.shuffle 메소드를 작성하시오
//		int[] original = {1,2,3,4,5,6,7,8,9};		
//		System.out.println(Arrays.toString(original));
		
		//int[] result = shuffle(original);		
		//System.out.println(Arrays.toString(result));
		
//		shuffle2(original);		
//		System.out.println(Arrays.toString(original));
		
	//	int lottoNum[] = randomProc(1, 45, 6);
	//	System.out.println(Arrays.toString(lottoNum));
		
//		int rNum[] = randomProc(1, 52, 52);
//		System.out.println(Arrays.toString(rNum));
		
		
		
		// 5.max메소드를 작성하시오.
		//int[] data = null;		
		//data = new int[10];
		
		//int[] data = { 3, 2, 9, 4, 7 };
//		int[] data = { 3, 2, 9, 4, 7, 12, 10, 1, 6 };
//		System.out.println(Arrays.toString(data));
//		System.out.println("최대값:"+ max(data));
		
		// isNumber메소드를 작성하시오
		String str = "123";
		System.out.println(str+"는 숫자입니까? "+ isNumber(str));
		str = "1234o";
		System.out.println(str+"는 숫자입니까? "+ isNumber(str));
		str = "1a234";
		System.out.println(str+"는 숫자입니까? "+ isNumber(str));
		
	}
						//   0        array
	//static void function(int num, int arr[]) {		
	//}	
	/*
	private static int[] getDouble(int[] num1) {
		for(int i = 0;i < num1.length; i++) {
			num1[i] = num1[i] * 2;
		}		
		return num1;
	}
	*/
	// 1.
	private static void getDouble(int[] num1) {
		for(int i = 0;i < num1.length; i++) {
			num1[i] = num1[i] * 2;
		}				
	}

	// 2.	
	static int getResult(int num1, int num2, int[] tag) {
		int result = num1 / num2;
		tag[0] = num1 % num2;
		
		return result;
	}
	
	// 3.
	static double getDistance(int x, int y, int x1, int y1) {
		int yy = (int)Math.pow(y1 - y, 2);
		int xx = (int)Math.pow(x1 - x, 2);
		double result = Math.sqrt(yy + xx);
		
		return result;
	}
	
	// 4. swap을 사용한 shuffle	
	static int[] shuffle(int[] original) {
		for(int i = 0;i < 1000; i++) {
			int x = (int)(Math.random()*9);	// 0 ~ 8
			int y = (int)(Math.random()*9);	// 0 ~ 8
			
			int temp = original[x];
			original[x] = original[y];
			original[y] = temp;
		}
		return original;
	}
	
	static void shuffle2(int[] original) {
		for(int i = 0;i < 1000; i++) {
			int x = (int)(Math.random()*9);	// 0 ~ 8
			int y = (int)(Math.random()*9);	// 0 ~ 8
			
			int temp = original[x];
			original[x] = original[y];
			original[y] = temp;
		}		
	}
	
	// random start 1 ~ 45
	static int[] randomProc(int start, int end, int size) {
		int rand_num[] = new int[size];
		boolean swit[] = new boolean[end - start + 1]; // 1 ~ 45 + 1
		
		int w = 0, r;
		while(w < size) {
			r = (int)(Math.random() * end);	// 배열 index
			if(swit[r] == false) {
				swit[r] = true;
				rand_num[w] = r + 1;
				w++;
			}
		}
		return rand_num;
	}
	
	static int max(int[] data) {
		if(data == null || data.length == 0) return -999999;
		
		int max = data[0];
		for(int i = 1;i < data.length; i++) {
			if(max < data[i]) {
				max = data[i];
			}			
		}
		
		return max;		
	}

	// 모두 숫자로 되어 있는지 검사하는 함수 -> Utility
	static boolean isNumber(String str) {
		if(str == null || str.equals("")) return false;
		
		boolean r = true;
		for(int i = 0;i < str.length(); i++) {
			char c = str.charAt(i);
			int asc = (int)c;
			if(asc < 48 || asc > 57) {
				r = false;
				break;
			}			
		}
		return r;
	}
	
	
}








