import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class MainClass {
	public static void main(String[] args) {
		
		// Null Pointer Exception
		int array[] = null;
		
		System.out.println(array);
		try {
			System.out.println(array.length);
		}catch (Exception e) {
			System.out.println("배열이 할당되지 않음");
		}
		
		
		/*			
		try {
			System.out.println(array.length);			
		}catch (NullPointerException e) {
			array = new int[3];
			System.out.println("할당되었음");
		}	
		
		if(array == null) {
			array = new int[3];
			System.out.println("할당되었음");
		}
		*/
				
		// ArrayIndexOutOfBoundsException
		int array1[] = { 1, 2, 3 };
			
		try {
			System.out.println(array1[3]);
		}catch (ArrayIndexOutOfBoundsException e) {
			//e.printStackTrace();
			System.out.println("배열의 범위를 넘어갔음");
		}
		
		// FileNotFoundException
		File file = new File("c:\\xxx.txt");
		FileInputStream fis;
		
		try {
			fis = new FileInputStream(file);
		}catch (FileNotFoundException e) {
			System.out.println("파일을 찾을 수 없습니다"); 
		}

		// NumberFormatException
		int num;		
		try {
			num = Integer.parseInt("123.456");
		}catch (NumberFormatException e) {
			System.out.println("숫자의 형태가 다릅니다");
		}		
		
	}
}



