import cls.MyTv2;
import game.Game;

public class MainClass {
	public static void main(String[] args) {
		//Sorting sort = new Sorting();
		//sort.input();
		
//		Student s = new Student();
//		
//		s.name = "홍길동";
//		s.ban = 1;
//		s.no = 1;
//		s.kor = 100;
//		s.eng = 60;
//		s.math = 76;
//		
//		System.out.println("이름:"+ s.name);
//		System.out.println("총점:"+ s.getTotal(s.kor, s.eng, s.math) );
//		System.out.println("평균:"+ s.getAverage());		
		
		
		// 코드를 넣어 완성하시오		
//		MyTv2 t = new MyTv2();
//		
//		t.setChannel(10);
//		System.out.println("CH:"+ t.getChannel());		
//		t.setVolume(20);
//		System.out.println("VOL:"+ t.getVolume());	
		
		
		Game game = new Game();
		game.play();
		
	}
}

class Student{
	String name;
	int ban;
	int no;
	int kor, eng, math;
	
	public void method() {		
	}
	
	public int getTotal(int k, int e, int m) {
		/*
		kor = k;
		eng = e;
		math = m;
		
		return (kor + eng + math);*/
		
		return (k + e + m);
	}
	
	public double getAverage() {
		//return (kor + eng + math) / 3;
		return (double)getTotal(kor, eng, math) / 3;
	}	
}



class Sorting{
	// (멤버)변수
	private int number[];
	
	// getter
	// setter
	
	
	// (멤버)method(함수)
	// 입력
	void input() {
		
	}
	
	// 정렬처리
	void sort() {
		
	}
	
	// 결과출력
	
	// 교환처리
	
	
}










