package game;

import java.util.Scanner;

public class Game {
	Scanner sc = new Scanner(System.in);
	
	private int coin = 20;
	private int batting;
	
	private int userNumber;
	
	Dice diceOne = new Dice();
	Dice diceTwo = new Dice();

	public void init() {
		diceOne.setRandom();
		diceTwo.setRandom();
		
		System.out.println("주사위1: " + diceOne.getNumber());
		System.out.println("주사위2: " + diceTwo.getNumber());
		
		System.out.println("합계: " + (diceOne.getNumber() + diceTwo.getNumber()));
	}
	
	public void userInput() {		
		while(true) {
			System.out.print("주사위의 합 = ");
			userNumber = sc.nextInt();
			if(userNumber == 2 || userNumber == 12) {
				System.out.println("잘못입력하셨습니다. 다시 입력하세요");
				continue;
			}
			break;
		}
		
		System.out.print("베팅할 금액 = ");
		batting = sc.nextInt();
		
		// 지참금 - 베팅금액
		coin = coin - batting;
	}
	
	public void game() {	// 판정
		int diceSum = diceOne.getNumber() + diceTwo.getNumber();
		
		if(userNumber == diceSum) {	// 맞췄다
			if(diceSum == 3 || diceSum == 11) {
				batting = batting * 18;
			}
			else if(diceSum == 4 || diceSum == 10) {
				batting = batting * 12;
			} 
			else if(diceSum == 5 || diceSum == 9) {
				batting = batting * 9;
			}
			else if(diceSum == 6 || diceSum == 8) {
				batting = batting * 7;
			}	
			else if(diceSum == 7) {
				batting = batting * 6;
			}
			
			System.out.println("빙고! 축하합니다");
			coin = coin + batting;
			
		}
		else {	// 못맞췄다
			System.out.println("아쉽습니다. 다시 도전하세요");
		}
	}
	
	public void result() {
		System.out.println("주사위1:" + diceOne.getNumber());
		System.out.println("주사위2:" + diceTwo.getNumber());
		
		System.out.println("주사위의 합:" + (diceOne.getNumber() + diceTwo.getNumber()));
		System.out.println("현재금액:" + coin);
	}
	
	public void play() {
		
		while(true) {
			init();
			userInput();
			game();
			result();
			
			System.out.print("play again(y/n) >> ");
			String again = sc.next();
			
			if(again.equals("n")) {
				System.out.println("안녕히 가십시오");
				break;
			}
			
			System.out.println("play restart!!");
		}
	}
	
}










