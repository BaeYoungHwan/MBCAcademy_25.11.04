package cls;

public class MyTv2 {
	boolean isPowerOn; 
	int channel; 
	int volume;
	
	public void setChannel(int ch) {
		channel = ch;
	}	
	public int getChannel() {
		return channel;
	}
	
	public int getVolume() {
		return volume;
	}
	public void setVolume(int vol) {
		volume = vol;
	}
	
	
}




