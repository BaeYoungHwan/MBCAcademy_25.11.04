import java.util.Arrays;

public class MainClass {
	public static void main(String[] args) {
		/*
			Array : 배열
					변수의 확장판
			정의: 같은 자료형의 묶음 2 ~ n개
			목적: 관리를 용의하게 하기 위함  
									
			1개의 변수
			int number;			
			number = 1;
			number = 11;
						
			(index)번호로 접근, 관리
			
			형식:
										 
				자료형 (배열)변수명[] = new 자료형[배열의 갯수];
									동적할당 <> 정적(static)
				index number의 범위   0 ~ 배열의 갯수-1
										
		*/
		int count1, count2, count3;
		count1 = 90;
		count2 = 85;
		count3 = 100;
		
	//	int count[] = new int[3];	// 0 ~ 2
	//	int []count = new int[3];	// 0 ~ 2
		int[] count = new int[3];	// 0 ~ 2
		
		count[0] = 90;	// 0 -> index number
		count[1] = 85;
		count[2] = 100;
		
		// (변수)초기화
		int number;		
		number = 0;	// initialize(초기화)
		
		int arrNumber[] = null;	// (0x00) (0)
		// 선언 후 할당도 가능하다
		arrNumber = new int[10];
		
		// 배열의 갯수
		System.out.println(arrNumber.length);
		System.out.println(count.length);
		
		//delete[] count;	// -> 가비지 컬렉터
		
		// 배열 (데이터)초기화
		int number1 = 0;
		
		//int array[] = { 1, 2, 3, 4, 5 };
		//int []array = { 1, 2, 3, 4, 5 };
		int[] array = { 1, 2, 3, 4, 5 };
		
		System.out.println(array[2]);
		
		//int array1[] = null;
		//array1 = { 1, 2, 3, 4, 5 };		
		
		
		// 배열의 별명(alias)
		int baseArr[] = { 1, 2, 3 };
		int aliasArr[] = baseArr;
		
		System.out.println(aliasArr[0]);
		System.out.println(aliasArr[1]);
		System.out.println(aliasArr[2]);
		
		aliasArr[1] = 9;
		
		System.out.println(baseArr[1]);
		
		int myDataArrayPos[] = new int[100]; 		
		int iArrPos[] = myDataArrayPos;
		
		{
			int dataOne[] = { 1, 2, 3, 4, 5 };
			int dataTwo[] = { 2, 4, 6, 8, 10 };
			
			System.out.println(dataOne);
			System.out.println(dataTwo);
			
			System.out.println(Arrays.toString(dataOne));
			System.out.println(Arrays.toString(dataTwo));
			
			//int temp = dataOne[0];
			//dataOne[0] = dataTwo[0];  
			//dataTwo[0] = temp;
			
			int one[] = dataOne;
			int two[] = dataTwo;
			
			System.out.println(Arrays.toString(one));
			System.out.println(Arrays.toString(two));
			
			int temp[] = null;
			temp = one;
			one = two;
			two = temp;
			
			System.out.println(Arrays.toString(one));
			System.out.println(Arrays.toString(two));
			
		}
		
	}
}








