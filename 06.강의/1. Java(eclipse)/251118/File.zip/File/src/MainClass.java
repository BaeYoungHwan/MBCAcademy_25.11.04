import java.io.File;
import java.io.IOException;

public class MainClass {
	public static void main(String[] args) {
		/*
			file, database => 저장매체, 기능
			source code => login 구현
			
			name	age		address
			홍길동	24		서울시
			
			목적: 데이터의 저장 및 불러오기
			
			*.txt	-> *.java	*.cpp   *.py
			*.jpg, *.exe *.png *.pdf 
			
			// module -> 
			*.lib -> library				-> 정적 					
			*.dll -> dynamic link library -> 동적	
			
			*.jar -> java module file
		*/
		
		// 파일 목록을 검색
		File file = new File("c:\\");
		
		// 파일명으로 문자열을 취득
		//String fileList[] = file.list();
		
		// 디렉토리(=폴더) + 파일명을 출력
		/*
		for (int i = 0; i < fileList.length; i++) {
			System.out.println(fileList[i]);
		}*/
		
		// 각 파일의 정보를 취득
		/*
		File fileList[] = file.listFiles();
		
		for (int i = 0; i < fileList.length; i++) {
			if(fileList[i].isFile()) {
				System.out.println("[파일]" + fileList[i].getName());
			}
			else if(fileList[i].isDirectory()) {
				System.out.println("[폴더]" + fileList[i].getName());
			}
			else {
				System.out.println("[?]" + fileList[i].getName());				
			}			
		}
		*/
		
		// 파일 생성
		File newFile = new File("c:\\tmp\\newfile.txt");
		
		
		try {
			if(newFile.createNewFile()) {	// 파일이 생성되는 처리
				System.out.println("파일생성 성공!");
			}else {
				System.out.println("파일생성되지 않음");
			}
		} catch (IOException e) {			
			e.printStackTrace();
		}
		
		// 파일의 존재여부
		if(newFile.exists()) {
			System.out.println("파일이 존재합니다");
		}else {
			System.out.println("파일이 존재하지 않습니다");
		}
		
		// 파일의 읽기여부
		if(newFile.canRead()) {
			System.out.println("파일을 읽을 수 있습니다");
		}else {
			System.out.println("파일을 읽을 수 없습니다");
		}
		
		// 파일 읽기 전용
		newFile.setReadOnly();
		
		// 파일 쓰기여부
		if(newFile.canWrite()) {
			System.out.println("파일 쓰기를 할 수 있습니다");			
		}else {
			System.out.println("파일 쓰기를 할 수 없습니다");
		}
		
		// 파일 삭제
		if(newFile.delete()) {
			System.out.println("파일이 삭제되었습니다");
		}else {
			System.out.println("파일이 삭제되지 않았습니다");
		}		

	}
}











