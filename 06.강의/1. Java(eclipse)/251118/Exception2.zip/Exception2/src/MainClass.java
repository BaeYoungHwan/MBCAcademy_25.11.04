import java.util.InputMismatchException;
import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		/*
		int array[] = { 1, 2, 3, 4, 5 };
		
		System.out.println("프로그램 시작");
		
		try {
		//	for (int i = 0; i < 6; i++) {
		//		System.out.println(array[i]);
		//	}
			System.out.print("number = ");
			array[4] = sc.nextInt();
			
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("배열 범위 초과");
		}catch (InputMismatchException e) {
			System.out.println("숫자가 입력이 안됨"); 
			//return;
		}finally {
			System.out.println("반드시 실행");			
		}		

		System.out.println("프로그램 종료");*/
		
		try {
			function();
		}catch (InputMismatchException e) {
			System.out.println("문자입력됨");
		}
	}
	
	static void function() throws InputMismatchException {
		Scanner sc = new Scanner(System.in);
		
	//	try {
			System.out.print("number = ");
			int number = sc.nextInt();
	//	}catch (InputMismatchException e) {
	//		System.out.println("문자가 입력되었음");
	//	}		
	}
	
}







