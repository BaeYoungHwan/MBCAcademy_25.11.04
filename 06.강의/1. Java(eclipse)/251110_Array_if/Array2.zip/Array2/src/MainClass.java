import java.util.Arrays;
import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		/*
			2차원배열
			1차원배열을 확장한 배열
			
			int array[] = { 1, 2, 3, 4, 5 };
			
			int array[] = new int[5];
			array[0] = 11;
			array[1] = 22;
			array[2] = 33;
			array[3] = 44;
			array[4] = 55;
			
			2차원배열
			int array2[][] = new int[3][4];
			int []array2[] = new int[3][4];			
			int [][]array2 = new int[3][4];								
									
		*/
		//int array[] = new int[5];
		//System.out.println(Arrays.toString(array));
		
		//int array2[][] = new int[3][4];	// 3 x 4
		
		int array2[][] = {
				{ 1, 2, 3, 4 },
				{ 5, 6, 7, 8 },
				{ 9, 10, 11, 12 }				
		};
		
		// array2[0][0] -> 1
		// array2[0][1] -> 2
		// array2[0][2] -> 3
		// array2[0][3] -> 4
		
		// array2[1][0] -> 5
		// array2[1][1] -> 6
		// array2[1][2] -> 7
		// array2[1][3] -> 8
		
		
		int [][]arrayTwo = new int[5][3];
		
		int array1[] = new int[3];
		array1[0] = 1;
		array1[1] = 2;
		array1[2] = 3;
		
		arrayTwo[0] = array1;
		
		/*
		int arrayTwo[][] = {
				{ 1, 2, 3 },		
				{ 4, 5, 6 },						
		};
		*/
		
		int array12[] = new int[3];
		array1[0] = 4;
		array1[1] = 5;
		array1[2] = 6;
		
		arrayTwo[1] = array12;
		
		
		int [][]arrayThree = new int[2][3];
		arrayThree[0][0] = 1;	// 0 -> 0
		arrayThree[0][1] = 2;	// 0 -> 1
		arrayThree[0][2] = 3;	// 0 -> 2
		
		arrayThree[1][0] = 4;	// 1 -> 0
		arrayThree[1][1] = 5;	// 1 -> 1
		arrayThree[1][2] = 6;	// 1 -> 2
		
		int arrayFour[][] = new int[3][];

		int arr1[] = { 1, 2 };
		int arr2[] = { 3, 4, 5 };
		int arr3[] = { 6, 7, 8, 9 };
		
		arrayFour[0] = arr1;
		arrayFour[1] = arr2;
		arrayFour[2] = arr3;
		
		System.out.println(Arrays.toString(arrayFour[0]));
		System.out.println(Arrays.toString(arrayFour[1]));
		System.out.println(Arrays.toString(arrayFour[2]));
		
		// user 로부터 원하는 갯수를 입력받고 배열을 할당하시오
		// 예) user -> 3
		// 1차원 배열 ?개를 할당하시오
		Scanner sc = new Scanner(System.in);
		
		int count = 0;		
		System.out.print("원하는 수의 갯수 >> ");
		count = sc.nextInt();
		
		//int inputNumber[] = new int[count];
		int inputNumber[][] = new int[count][3];		
		
	}
}









