
public class MainClass {

	public static void main(String[] args) {
		/*
			조건문
			
			논리연산자 : &&(AND), ||(OR), !
			
			등호, 부등호 : > < >= <= == !=  
			
			형식:
				if( 조건(true/false) ){
					처리			
				}
		*/	
		
		int number = 1;
		
		if(number > 0) {
			System.out.println("number는 양수입니다");
		}
		
		number = -3;		
		if(number >= -2) {
			System.out.println("number는 -2보다 큽니다");
		}
		
		number = 33;
		if(number == 33) {
			System.out.println("number는 33입니다");
		}
		
		number = 17;
		if(number > 0 && number <= 30) {	// 1 ~ 30
			System.out.println("number는 0보다 크고 30보다 작거나 같습니다");
		}
		
		if(number > 10 && number < 20) {	// 11 ~ 19
			System.out.println("number는 10보다 크고 20보다 작습니다");
		}
		
		if(number % 2 == 0) { 
			System.out.println("number는 2의 배수입니다");
		}		
		
		boolean isS = true;
		
	//	if(isS == true) {
		if( isS ) {
			System.out.println("isS는 true입니다");
		}
		
		isS = false;
		//if(isS == false) {
		if( !isS ) {
			System.out.println("isS는 false입니다");
		}
		
		// wrapper class - String
		String str1 = "Hello";
		String str2 = "Hell";
		
		str2 = str2 + "o";
		
		if(str1 == str2) {
			System.out.println("같은 문자열입니다");
		}
		
		boolean b = str1.equals(str2);
		if( b ) {
		//if( str1.equals(str2) ) {
			System.out.println("str1과 str2는 같은 문자열입니다");
		}
		
		number = 7;
		if(number != 0 && number > 5 && number % 2 == 1) {
			System.out.println("number는 0이 아니고, 5보다 크며, 홀수입니다");
		}
		
		String str3 = "ABC";
		
		// X
		if(str3 != "") {
			System.out.println("str3 != \"\"");
		}
		
		// O
		if(!str3.equals("")) {
			System.out.println("str3는 빈 문자열이 아닙니다");
		}
		
		/*
			형식:
				if( 조건 ){
					처리 1
				}
				else{
					처리 2
				}
		*/
		
		number = 5;
		if(number > 5) {
			System.out.println("number는 5보다 큽니다");
		}
		else {
			System.out.println("number는 5보다 작거나 같습니다");
		}
		
		/*
		  	형식:
		  		if(조건 1){
		  			처리 1
		  		}
		  		else if(조건 2){
		  			처리 2
		  		}
		  		else if(조건 3){
		  			처리 3
		  		}
		  		else if(조건 n){
		  			처리 n
		  		}
		  		else{	<--- 생략이 가능
		  			처리
		  		}		  	
		 */
		
		int count = 85;
		
		if(count == 100) {
			System.out.println("A+입니다");
		}
		else if(count >= 90) {
			System.out.println("A입니다");
		}
		else if(count >= 80) {
			System.out.println("B입니다");
		}
		else if(count >= 70) {
			System.out.println("C입니다");
		}
		else {
			System.out.println("재시험입니다");
		}
		
		if(count >= 70 && count < 80) {
			System.out.println("C입니다");
		}
		else if(count >= 80 && count < 90) {
			System.out.println("B입니다");
		}
		else if(count >= 90 && count < 100) {
			System.out.println("A입니다");
		}
		else if(count == 100) {
			System.out.println("A+입니다");
		}
		
		// 조건문 안에 조건문
		count = 86;
		
		if(count > 80 && count < 90) {			
			if(count > 85) {
				System.out.println("우수입니다");
			}
			else {
				System.out.println("평균입니다");
			}			
		}
		
		if(count > 80 && count < 90) {			
			if(count > 85) {
				System.out.println("우수입니다");
			}
			else {
				System.out.println("평균입니다");
			}			
		}
		
		if(count > 85 && count < 90) {	
			
		}
		else if(count > 80 && count <= 85) {	
			
		}
		
		
		
		
	}
}


