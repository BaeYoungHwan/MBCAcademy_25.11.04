
public class MainClass {
	public static void main(String[] args) {
		// 논리(true/false) 연산자(operator)
		/*
			&&		AND		a 그리고 b
			||		OR		a 또는 b
			!		NOT		~아닌
			
			제어문과 같이 사용된다
			if while
			
			> < >= <= == != 			
		*/
		int number = 0;
		// AND
		/*
			false(0) false(0) -> false(0) 
			false(0) true(1) -> false(0)
			true(1) false(0) -> false(0)
			true(1) true(1) -> true(1)
		*/
		System.out.println(number >= 0 && number < 10);
		System.out.println(number > 0 && number < 10);
		
		// OR
		/*
		  	false(0) false(0) -> false(0)
		  	false(0) true(1) -> true(1)
		  	true(1) false(0) -> true(1)
		  	true(1) true(1) -> true(1)		  
		 */
		System.out.println(number > 0 || number < 10);
		System.out.println(number >= 0 || number < 10);
		System.out.println(number < 0 || number >= 10);
		
		// NOT
		/*
			false(0) -> true(1)
			true(1) -> false(0)
		*/
		System.out.println(number == 0);
		System.out.println(number != 0);
		//System.out.println(!number);
		
		boolean b = false;
		System.out.println(b);
		System.out.println(!b);
		System.out.println(b == false);
		
		System.out.println(!(number > 0 && number < 10));
		System.out.println(number <= 0 || number >= 10);
		
		number = 10;
		System.out.println(!(number >= 10 && number <= 20));
		System.out.println(number < 10 || number > 20);		
		System.out.println(number < 10);
		System.out.println(number >= 10);
		
		// 삼항연산자
		/*
			조건에 따라서 값을 대입
			형식:
				값 = (조건) ? "값1":"값2";			
		*/
		number = 5;
		
		char c;
		c = (number > 0) ? 'Y':'N';
		System.out.println("c:" + c);
		
		int n;
		n = (number % 2 == 0)  ? 2 : 1;
		System.out.println("n:" + n);
		
		number = 1;
		String answer;
		answer = (number >= 3) ? "3보다 크거나 같다":"3보다 작다";
		System.out.println(answer);
	}
}




