import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		/*
			하나의 수를 입력받고 삼항 연산자를 사용하여 양수인지 음수인지 판단하라.
			
			변수 = (조건) ? "값1":"값2";			
		*/
//		Scanner sc = new Scanner(System.in);
//		
//		System.out.print("숫자 = ");
//		int number = sc.nextInt();
//		
//		String str = (number > 0)?"양수":"음수";		
//		System.out.println(str + "입니다");
		
		
		
		//범위: 0 ~ 99  개수: 1개
		int rand_number = (int)(Math.random() * 100);
		System.out.println("랜덤값:" + rand_number);
		
		//범위: 11, 12, 13, 14, 15  개수: 1개
		int rand_num = (int)(Math.random() * 5) + 11;	// 0 ~ 4 + 11
		System.out.println("랜덤값:" + rand_num);
		
		//범위: 1 ~ 45  개수: 6
		int number1 = (int)(Math.random() * 45) + 1;
		int number2 = (int)(Math.random() * 45) + 1;
		int number3 = (int)(Math.random() * 45) + 1;
		int number4 = (int)(Math.random() * 45) + 1;
		int number5 = (int)(Math.random() * 45) + 1;
		int number6 = (int)(Math.random() * 45) + 1;
		
		
		
		
	}
}





