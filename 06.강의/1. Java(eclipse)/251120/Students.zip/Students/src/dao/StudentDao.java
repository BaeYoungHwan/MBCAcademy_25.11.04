package dao;

import java.util.Scanner;

import dto.StudentDto;

public class StudentDao {
	Scanner sc = new Scanner(System.in);

	private StudentDto students[];
	private int count;
	
	public StudentDao() {
		students = new StudentDto[10]; // 배열만 할당
				
//		for (int i = 0; i < students.length; i++) {
//			students[i] = new StudentDto();
//		}
		
		count = 0;
	}
	
	public void insert() {
		System.out.print("이름 >> ");
		String name = sc.next();
		
		System.out.print("나이 >> ");
		int age = sc.nextInt();
		
		System.out.print("신장 >> ");
		double height = sc.nextDouble();
		
		System.out.print("주소 >> ");
		String address = sc.next();
		
		students[count] = new StudentDto(name, age, height, address);
		count++;
	}
	
	public void delete() {
		
	}
	
	public void select() {
		System.out.print("검색할 이름 >> ");
		String name = sc.next();
		
		int index = -1;
		for (int i = 0; i < students.length; i++) {
			if(students[i] != null) {
				if(name.equals(students[i].getName())) {
					index = i;
					break;
				}
			}
		}
		
		if(index == -1) {
			System.out.println("학생명단에 없습니다");
			return;		// 함수에서 break 역활
		}
		
		// 학생정보 출력	
		System.out.println("학생정보입니다");
		System.out.println(students[index].toString());
	}
	
	public void update() {
		
	}
	
	public void allprint() {
		for (StudentDto st : students) {
			if(st != null) {
				System.out.println(st.toString());
			}
		}
	}	
	
	public int search() {
		
		return 1;
	}
}







