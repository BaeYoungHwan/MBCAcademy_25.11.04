package main;

import java.util.Scanner;

import dao.StudentDao;

public class Main {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		StudentDao dao = new StudentDao();
		
		while(true) {
			System.out.println("<< 학생정보프로그램 >>");
			System.out.println("1.학생정보추가");	
			System.out.println("2.학생정보삭제");
			System.out.println("3.학생정보검색");
			System.out.println("4.학생정보수정");	// 주소만 수정
			System.out.println("5.학생정보 모두출력");
			
			System.out.print("메뉴번호선택 >> ");
			int number = sc.nextInt();	
			
			switch(number) {
				case 1:
					dao.insert();
					break;
				case 2:
					
					break;
				case 3:
					dao.select();
					break;
				case 4:			
					
					break;
				case 5:
					dao.allprint();
					break;			
			}
			
		}
		
	}
}
