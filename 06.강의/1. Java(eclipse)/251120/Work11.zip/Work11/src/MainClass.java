import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) throws Exception {
		/*
		Scanner sc = new Scanner(System.in);
		
		String students[][] = new String[3][3];
		
		for(int i = 0;i < students.length; i++) {
			System.out.print("이름:");
			students[i][0] = sc.next();
			
			System.out.print("나이:");
			students[i][1] = sc.next();
			
			System.out.print("주소:");
			students[i][2] = sc.next();
		}
		*/
		/*
			홍길동-24-서울시
			사민-6-광주광역시
			선우대형-34-대구시			
		*/
		/*
		// token을 포함해서 문자열배열로 만들어 준다
		String saveData[] = new String[students.length];
		for (int i = 0; i < saveData.length; i++) {
			saveData[i] = students[i][0] + "-" + students[i][1] + "-" + students[i][2];
		}
		
		System.out.println(Arrays.toString(saveData));
		*/
		
		
		File file = new File("c:\\tmp\\student.txt");
		/*
		// data 를 file 에 쓰기
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
		
		for (int i = 0; i < saveData.length; i++) {
			pw.println(saveData[i]);
		}
		pw.close();
		*/
		
		// file 로부터 데이터 읽기
		String readData[][] = new String[3][3];
		
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		
		String str = "";
		int index = 0;
		while((str = br.readLine()) != null) {
			// System.out.println(str);
			
			String array[] = str.split("-");  // <- 홍길동-24-서울시
			
			readData[index][0] = array[0];
			readData[index][1] = array[1];
			readData[index][2] = array[2];			
			index++;
		}
		br.close();
		
		for (int j = 0; j < readData.length; j++) {
			System.out.println("이름:" + readData[j][0] + " 나이:" + readData[j][1] + " 주소:" + readData[j][2]);			
		}
		
		
	}
}





